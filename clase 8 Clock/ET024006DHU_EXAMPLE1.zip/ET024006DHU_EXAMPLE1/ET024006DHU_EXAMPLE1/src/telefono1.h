

#ifndef telefono1_H_
#define telefono1_H_
extern const unsigned short int telefono1[];
#endif
