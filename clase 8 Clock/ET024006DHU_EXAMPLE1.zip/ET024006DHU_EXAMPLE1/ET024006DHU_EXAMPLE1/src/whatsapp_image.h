

#ifndef whatsapp_image_H_
#define whatsapp_image_H_
extern const unsigned short int whatsapp_image[];
#endif
