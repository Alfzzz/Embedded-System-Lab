

#ifndef brujula_H_
#define brujula_H_
extern const unsigned short int brujula[];
#endif
