

#ifndef telefono2_H_
#define telefono2_H_
extern const unsigned short int telefono2[];
#endif
